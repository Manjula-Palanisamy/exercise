﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using EXC.Helper;
using EXC.Models;
using Newtonsoft.Json;

namespace EXC.DTO
{
    public class UserRegisterDataProvider
    {
        private static class MethodCall
        {
            public static string insertUpdateUserRegister = "UserRegister/InsertUpdateUserRegister";
            public static string loadUserRegisterDetails = "UserRegister/LoadUserRegisterDetails";
        }
        public static int InsertUpdateUser(UserRegister model)
        {
            int activationResult = 0;
            HttpClient httpClient = APIHelper.Initial();
            var userTask = httpClient.PostAsync(MethodCall.insertUpdateUserRegister, APIHelper.ConvertData<UserRegister>(model));
            userTask.Wait();
            var result = userTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsStringAsync().Result;
                activationResult = JsonConvert.DeserializeObject<int>(readTask);
                return activationResult;
            }
            else
            {
                return -111;
            }
        }
        public static List<UserRegisterList> LoadUserDetails(UserRegisterGrid categorySearch)
        {
            List<UserRegisterList> Result = new List<UserRegisterList>();
            HttpClient client = APIHelper.Initial();
            var responseTask = client.PostAsync(MethodCall.loadUserRegisterDetails, APIHelper.ConvertData<UserRegisterGrid>(categorySearch));
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsStringAsync().Result;
                Result = JsonConvert.DeserializeObject<List<UserRegisterList>>(readTask);
            }
            return Result;
        }
    }
}

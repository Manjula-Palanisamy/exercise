﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace EXC.Helper
{
    public sealed class APIHelper
    {
        public static HttpClient Initial()
        {
            try
            {
                string Baseurl = "https://localhost:44327/api/";
                var Client = new HttpClient();
                Client.BaseAddress = new Uri(Baseurl);
                return Client;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to connect with database server. Please contact your network administrator." + ex.Message);
            }
        }
        public static StringContent ConvertData<T>(T items)
        {
            try
            {
                var myContent = JsonConvert.SerializeObject(items);
                var stringContent = new StringContent(myContent, UnicodeEncoding.UTF8, "application/json");
                //var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                return (stringContent);
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to connect with database server. Please contact your network administrator." + ex.Message);
            }

        }
    }
}

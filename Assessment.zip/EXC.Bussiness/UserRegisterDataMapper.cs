﻿using EXC.DTO;
using EXC.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EXC.Bussiness
{
    public class UserRegisterDataMapper
    {
        public List<UserRegisterList> LoadUserDetails(UserRegisterGrid categorySearch)
        {
            return UserRegisterDataProvider.LoadUserDetails(categorySearch);
        }
        public int InsertUpdateUser(UserRegister updateLoginLogoutStatus)
        {
            return UserRegisterDataProvider.InsertUpdateUser(updateLoginLogoutStatus);
        }
    }
}

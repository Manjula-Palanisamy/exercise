﻿using EXC.Bussiness;
using EXC.Models;
using GoogleMaps.LocationServices;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace EXC.WEB.Controllers
{
    public class UserRegisterController : Controller
    {
        public static UserRegisterDataMapper _bussinessCommonCall = new UserRegisterDataMapper();
        // GET: UserRegister
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Index(UserRegister model)
        {
            return View();
        }

        [HttpGet]
        public ActionResult InsertUpdateUser(int? UserRegisterID)
        {
            UserRegister userRegister = new UserRegister();
            if (UserRegisterID == null)
            {
                UserRegisterID = 0;
            }
            userRegister.UserRegisterID = (int)UserRegisterID;

            if (UserRegisterID > 0)
            {
                UserRegisterGrid model = new UserRegisterGrid();
                model.PageNo = 1;
                model.SortColumn = "firstname desc";
                model.RecordsPerPage = 1;
                model.UserRegisterID = userRegister.UserRegisterID;
                List<UserRegisterList> userRegisterLists = new List<UserRegisterList>();
                userRegister.UserRegisterList = _bussinessCommonCall.LoadUserDetails(model);
                userRegister.FirstName = userRegister.UserRegisterList[0].FirstName;
                userRegister.LastName = userRegister.UserRegisterList[0].LastName;
                userRegister.Email = userRegister.UserRegisterList[0].Email;
                userRegister.Phonenumber = userRegister.UserRegisterList[0].Phonenumber;
                userRegister.Address = userRegister.UserRegisterList[0].Address;
                userRegister.City = userRegister.UserRegisterList[0].City;
                userRegister.State = userRegister.UserRegisterList[0].State;
                userRegister.Country = userRegister.UserRegisterList[0].Country;
                userRegister.PostalCode = userRegister.UserRegisterList[0].PostalCode;
            }
            return View(userRegister);
        }

        [HttpPost]
        public ActionResult InsertUpdateUser(UserRegister model)
        {
            if (ModelState.IsValid)
            {
                //GetCoOrdinates(model.Address, model.City, model.State);
                //var address = model.State;
                //var API = "http://maps.googleapis.com/maps/api/geocode/xml?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=true_or_false";
                //var locationService = new GoogleLocationService();
                //var point = locationService.GetLatLongFromAddress(address);
                //var latitude = point.Latitude;
                //var longitude = point.Longitude;
                //GetdtLatLong()
                model.ReturnStatus = _bussinessCommonCall.InsertUpdateUser(model);
            }
            return View(model);
        }
        //public DataTable GetdtLatLong(string url)
        //{

        //    DataTable dtGMap = null;

        //    WebRequest request = WebRequest.Create(url);

        //    using (WebResponse response = (HttpWebResponse)request.GetResponse())

        //    {

        //        using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))

        //        {

        //            DataSet dsResult = new DataSet();

        //            dsResult.ReadXml(reader);

        //            DataTable dtCoordinates = new DataTable();

        //            dtCoordinates.Columns.AddRange(new DataColumn[4] { new DataColumn("Id", typeof(int)),

        //new DataColumn("Address", typeof(string)),

        //new DataColumn("Latitude",typeof(string)),
        //new DataColumn("Longitude",typeof(string)) });


        //            foreach (DataRow row in dsResult.Tables["result"].Rows)

        //            {

        //                string geometry_id = dsResult.Tables["geometry"].Select("result_id = " + row["result_id"].ToString())[0]["geometry_id"].ToString();

        //                DataRow location = dsResult.Tables["location"].Select("geometry_id =" + geometry_id)[0];

        //                dtCoordinates.Rows.Add(row["result_id"], row["formatted_address"], location["lat"], location["lng"]);

        //            }

        //            dtGMap = dtCoordinates;

        //            return dtGMap;

        //        }
        //    }
        //}
        //public void GetCoOrdinates(string street, string city, string state)
        //{
        //    string serviceUri = string.Format("http://rpc.geocoder.us/service/rest?address={0},{1},{2}", street, city, state);
        //    XmlDocument serviceXmlDoc = new XmlDocument();
        //    serviceXmlDoc.Load(serviceUri);
        //    XmlNamespaceManager geoCoderManager = new XmlNamespaceManager(serviceXmlDoc.NameTable);
        //    geoCoderManager.AddNamespace("geoCoderService", @"http://www.w3.org/2003/01/geo/wgs84_pos#");
        //    string longitude = serviceXmlDoc.DocumentElement.SelectSingleNode(@"//geoCoderService:long", geoCoderManager).InnerText;
        //    string latitude = serviceXmlDoc.DocumentElement.SelectSingleNode(@"//geoCoderService:lat", geoCoderManager).InnerText;
        //    //MessageBox.Show(String.Format("Latitude: {0} Latitude: {1}", latitude, longitude));
        //}
        public ActionResult Map()
        {
            return View();
        }


        #region Server side pagination for User Details

        [HttpPost]
        //[OutputCache(CacheProfile = "CacheForAllParamWithUserAuth")]
        public ActionResult GetUserRegisterList(DataTableAjaxPostModel dataTableAjaxPostModel, UserRegisterGrid userRegisterGrid)
        {
            int columnIndex = 0, pageSize = 0, totalRecordCount = 0, totalFilteredRecordCount = 0;
            string sortDir = "DESC", searchValue = string.Empty;

            sortDir = dataTableAjaxPostModel.order[0].dir.ToString();
            pageSize = dataTableAjaxPostModel.length;
            searchValue = Request.Form["search[value]"];     //Global Search of all column data
            columnIndex = dataTableAjaxPostModel.order[0].column;
            var columnName = dataTableAjaxPostModel.columns[columnIndex].name;

            userRegisterGrid.PageNo = (dataTableAjaxPostModel.start + pageSize) / pageSize;
            userRegisterGrid.SortColumn = columnName + " " + sortDir;
            userRegisterGrid.RecordsPerPage = pageSize;

            List<UserRegisterList> userRegisterLists = new List<UserRegisterList>();



            userRegisterGrid.UserRegisterLists = _bussinessCommonCall.LoadUserDetails(userRegisterGrid);

            if (userRegisterGrid.UserRegisterLists.Count > 0)
            {
                totalRecordCount = userRegisterGrid.UserRegisterLists.FirstOrDefault().TotalRecordCount == null ? 0 : userRegisterGrid.UserRegisterLists.FirstOrDefault().TotalRecordCount.Value;
                totalFilteredRecordCount = totalRecordCount;
            }
            return Json(new
            {
                draw = dataTableAjaxPostModel.draw,
                recordsTotal = totalRecordCount,
                recordsFiltered = totalFilteredRecordCount,
                data = userRegisterGrid.UserRegisterLists
            }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Log Exception

        protected override void OnException(ExceptionContext filterContext)
        {
            string controllerName = (string)filterContext.RouteData.Values["controller"];
            string actionName = (string)filterContext.RouteData.Values["action"];
            string routeUrl = ((System.Web.Routing.Route)filterContext.RouteData.Route).Url;
            filterContext.ExceptionHandled = true;
            //ExceptionService service = new ExceptionService();

            //if (filterContext.HttpContext.Request.IsAjaxRequest())
            //{
            //    service.LogException(filterContext.Exception, controllerName, actionName, routeUrl, userId);
            //}
            //else
            //{
            //    string referenceId = service.LogException(filterContext.Exception, controllerName, actionName, routeUrl, userId);
            //    TempData["ReferenceId"] = referenceId;
            //    if (actionName == "Index")
            //    {
            //        filterContext.Result = RedirectToAction("Error", "Exception");
            //    }
            //    else
            //    {
            //        TempData["ReferenceErrorMessage"] = "Internal Error Occured Please Try again";
            //        filterContext.Result = RedirectToAction("Index", controllerName);
            //    }
            //}
        }

        #endregion
    }
}
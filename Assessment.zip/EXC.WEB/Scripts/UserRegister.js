﻿$('.mobile-phone-number').inputmask('999-999-9999');

function removeSpaces(string) {
    return $.trim(string);
};
$("#PostalCode").on("keypress", function (event) {
    $(this).val($(this).val().replace(/[^\d].+/, ""));
    if ((event.which < 48 || event.which > 57)) {
        event.preventDefault();
    }
});
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EXC.Models
{

    public class UserRegister
    {
        public int UserRegisterID { get; set; }
        public string EncryptedUserRegisterID { get; set; }

        [StringLength(50, MinimumLength = 3, ErrorMessage = "{0} cannot be longer than {1} characters.")]
        [Display(Name = "First Name")]
        [Required(ErrorMessage = "{0} is required")]
        public string FirstName { get; set; }

        [StringLength(50, MinimumLength = 3, ErrorMessage = "{0} cannot be longer than {1} characters.")]
        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "{0} is required")]
        public string LastName { get; set; }

        //[Display(Name = "E-mail Address")]
        //[EmailAddress(ErrorMessage = "{0} is not valid")]
        //[StringLength(80, ErrorMessage = "{0} cannot be longer than {1} characters.")]
        //[RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{3,6}$", ErrorMessage = "Invalid {0}")]
        //[Required(ErrorMessage = "{0} is required")]
        [Display(Name = "Email Address")]
        [EmailAddress(ErrorMessage = "Invalid {0}")]
        [StringLength(80, ErrorMessage = "{0} cannot be longer than {1} characters.")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{3,6}$", ErrorMessage = "Invalid {0}")]
        [Required(ErrorMessage = "{0} is required")]
        public string Email { get; set; }

        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "Phone Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid {0}")]
        public string Phonenumber { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "Address")]
        public string Address { get; set; }

        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "City")]
        public string City { get; set; }

        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "State")]
        public string State { get; set; }

        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "Country")]
        public string Country { get; set; }

        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "Postal Code")]
        [DataType(DataType.PostalCode)]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Invalid {0}")]
        public string PostalCode { get; set; }
        public int CreatedBy { get; set; }
        public int ReturnMessage { get; set; }
        public int ReturnStatus { get; set; }
        public List<UserRegisterList> UserRegisterList { get; set; }
        public int PageNo { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortColumn { get; set; }
        public string Latitude { get; set; }
        public string Longtitude { get; set; }
    }
    public class UserRegisterGrid
    {
        public int UserRegisterID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phonenumber { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public int CreatedBy { get; set; }
        public List<UserRegisterList> UserRegisterList { get; set; }
        public int PageNo { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortColumn { get; set; }
        public List<UserRegisterList> UserRegisterLists { get; set; }
        public string Latitude { get; set; }
        public string Longtitude { get; set; }
    }
    public class UserRegisterList
    {
        public int UserRegisterID { get; set; }
        public string EncryptedUserRegisterID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phonenumber { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public int CreatedBy { get; set; }
        public int PageNo { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortColumn { get; set; }
        public int? TotalRecordCount { get; set; }
        public string Latitude { get; set; }
        public string Longtitude { get; set; }
    }
    public class DataTableAjaxPostModel
    {
        // properties are not capital due to json mapping
        public int id { get; set; }
        public int draw { get; set; }
        public int start { get; set; }
        public int length { get; set; }
        public List<Column> columns { get; set; }
        public Search search { get; set; }
        public List<Order> order { get; set; }
    }

    public class Column
    {
        public string data { get; set; }
        public string name { get; set; }
        public bool searchable { get; set; }
        public bool orderable { get; set; }
        public Search search { get; set; }
    }

    public class Search
    {
        public string value { get; set; }
        public string regex { get; set; }
    }

    public class Order
    {
        public int column { get; set; }
        public string dir { get; set; }
    }
}
